# Cargo Expres

Sistema inteligente de planificación de rutas de entrega que optimiza recorridos mediante el algoritmo de Dijkstra.

## Problema
Las empresas pequeñas planifican rutas manualmente generando ineficiencia.

## Solución
Registro de paquetes, cálculo de rutas óptimas y visualización en mapa.

## Documentación
- docs/system-brief.md
- docs/requirements.md
